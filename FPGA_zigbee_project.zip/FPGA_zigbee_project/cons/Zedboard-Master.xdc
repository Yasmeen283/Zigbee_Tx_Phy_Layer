# ----------------------------------------------------------------------------
#     _____
#    /     \
#   /____   \____
#  / \===\   \==/
# /___\===\___\/  AVNET Design Resource Center
#      \======/         www.em.avnet.com/drc
#       \====/    
# ----------------------------------------------------------------------------
# 
#  Created With Avnet UCF Generator V0.4.0 
#     Date: Saturday, June 30, 2012 
#     Time: 12:18:55 AM 
# 
#  This design is the property of Avnet.  Publication of this
#  design is not authorized without written consent from Avnet.
#  
#  Please direct any questions to:
#     ZedBoard.org Community Forums
#     http://www.zedboard.org
# 
#  Disclaimer:
#     Avnet, Inc. makes no warranty for the use of this code or design.
#     This code is provided  "As Is". Avnet, Inc assumes no responsibility for
#     any errors, which may appear in this code, nor does it make a commitment
#     to update the information contained herein. Avnet, Inc specifically
#     disclaims any implied warranties of fitness for a particular purpose.
#                      Copyright(c) 2012 Avnet, Inc.
#                              All rights reserved.
# 
# ----------------------------------------------------------------------------
# 
#  Notes:
# 
#  10 August 2012
#     IO standards based upon Bank 34 and Bank 35 Vcco supply options of 1.8V, 
#     2.5V, or 3.3V are possible based upon the Vadj jumper (J18) settings.  
#     By default, Vadj is expected to be set to 1.8V but if a different 
#     voltage is used for a particular design, then the corresponding IO 
#     standard within this UCF should also be updated to reflect the actual 
#     Vadj jumper selection.
# 
#  09 September 2012
#     Net names are not allowed to contain hyphen characters '-' since this
#     is not a legal VHDL87 or Verilog character within an identifier.  
#     HDL net names are adjusted to contain no hyphen characters '-' but 
#     rather use underscore '_' characters.  Comment net name with the hyphen 
#     characters will remain in place since these are intended to match the 
#     schematic net names in order to better enable schematic search.
#
#  17 April 2014
#     Pin constraint for toggle switch SW7 was corrected to M15 location.
#
#  16 April 2015
#     Corrected the way that entire banks are assigned to a particular IO
#     standard so that it works with more recent versions of Vivado Design
#     Suite and moved the IO standard constraints to the end of the file 
#     along with some better organization and notes like we do with our SOMs.
#
#   6 June 2016
#     Corrected error in signal name for package pin N19 (FMC Expansion Connector)
#	
#
# ----------------------------------------------------------------------------

#-----------------------------timing constraints------------------------------
#-----------------------------------------------------------------------------

# create_clock -name clk -period 8 [get_ports clk]

# ==============================================================================
# ZedBoard Constraints File for IEEE 802.15.4 CSS PHY Transmitter (css_tx_top)
# Target Board: ZedBoard (xc7z020clg484-1)
# ==============================================================================

# ------------------------------------------------------------------------------
# 1. Primary Clock Definition (On-Board 100 MHz Oscillator)
# ------------------------------------------------------------------------------
set_property PACKAGE_PIN Y9 [get_ports clk]
set_property IOSTANDARD LVCMOS33 [get_ports clk]

# Primary 100 MHz System Clock (10.000 ns Period, 50% Duty Cycle)
create_clock -period 10.000 -name sys_clk -waveform {0.000 5.000} [get_ports clk]

# Clock Jitter and Timing Uncertainty Constraints
set_clock_uncertainty -setup 0.200 [get_clocks sys_clk]
set_clock_uncertainty -hold  0.050 [get_clocks sys_clk]

# ------------------------------------------------------------------------------
# 2. Asynchronous Control Inputs (Push Buttons & DIP Switches)
# Bank 34 (2.5V Voltage Domain)
# ------------------------------------------------------------------------------
# Active-High Reset -> Push Button BTNC (Center Pin P16)
set_property PACKAGE_PIN P16 [get_ports reset]
set_property IOSTANDARD LVCMOS25 [get_ports reset]

# start_tx Pulse -> Push Button BTNU (Up Pin N15)
set_property PACKAGE_PIN N15 [get_ports start_tx]
set_property IOSTANDARD LVCMOS25 [get_ports start_tx]



# CSK Sequence Select: chirp_index[1:0] -> button1, button0
set_property PACKAGE_PIN T18 [get_ports {chirp_index[0]}]
set_property PACKAGE_PIN R18 [get_ports {chirp_index[1]}]

set_property IOSTANDARD LVCMOS25 [get_ports {chirp_index[*]}]

# Payload RAM Write Enable: payload_we -> SW7
set_property PACKAGE_PIN M15 [get_ports payload_we]
set_property IOSTANDARD LVCMOS25 [get_ports payload_we]

# Payload Length Register: payload_length[6:0] 
set_property PACKAGE_PIN F22 [get_ports {payload_length[0]}] ;# SW0
set_property PACKAGE_PIN G22 [get_ports {payload_length[1]}] ;# SW1
set_property PACKAGE_PIN H22 [get_ports {payload_length[2]}] ;# SW2
set_property PACKAGE_PIN F21 [get_ports {payload_length[3]}] ;# SW3
set_property PACKAGE_PIN H19 [get_ports {payload_length[4]}] ;# SW4
set_property PACKAGE_PIN H18 [get_ports {payload_length[5]}] ;# SW5
set_property PACKAGE_PIN H17 [get_ports {payload_length[6]}] ;# SW6
set_property IOSTANDARD LVCMOS25 [get_ports {payload_length[*]}]

# ------------------------------------------------------------------------------
# 3. Memory & Address Buses (Mapped to PMOD Headers JC & JD)
# Bank 13 (3.3V Voltage Domain)
# ------------------------------------------------------------------------------
# Payload Write Data Bus: payload_wdata[7:0] -> Mapped to PMOD JC
set_property PACKAGE_PIN AB6 [get_ports {payload_wdata[0]}] ;# JC1_N
set_property PACKAGE_PIN AB7 [get_ports {payload_wdata[1]}] ;# JC1_P
set_property PACKAGE_PIN AA4 [get_ports {payload_wdata[2]}] ;# JC2_N
set_property PACKAGE_PIN Y4  [get_ports {payload_wdata[3]}] ;# JC2_P
set_property PACKAGE_PIN T6  [get_ports {payload_wdata[4]}] ;# JC3_N
set_property PACKAGE_PIN R6  [get_ports {payload_wdata[5]}] ;# JC3_P
set_property PACKAGE_PIN U4  [get_ports {payload_wdata[6]}] ;# JC4_N
set_property PACKAGE_PIN T4  [get_ports {payload_wdata[7]}] ;# JC4_P
set_property IOSTANDARD LVCMOS33 [get_ports {payload_wdata[*]}]

# Payload Write Address Bus: payload_waddr[6:0] -> Mapped to PMOD JD
set_property PACKAGE_PIN W7  [get_ports {payload_waddr[0]}] ;# JD1_N
set_property PACKAGE_PIN V7  [get_ports {payload_waddr[1]}] ;# JD1_P
set_property PACKAGE_PIN V4  [get_ports {payload_waddr[2]}] ;# JD2_N
set_property PACKAGE_PIN V5  [get_ports {payload_waddr[3]}] ;# JD2_P
set_property PACKAGE_PIN W5  [get_ports {payload_waddr[4]}] ;# JD3_N
set_property PACKAGE_PIN W6  [get_ports {payload_waddr[5]}] ;# JD3_P
set_property PACKAGE_PIN U5  [get_ports {payload_waddr[6]}] ;# JD4_N
set_property IOSTANDARD LVCMOS33 [get_ports {payload_waddr[*]}]

# ------------------------------------------------------------------------------
# 4. Status Outputs (On-Board LEDs)
# Bank 33 (3.3V Voltage Domain)
# ------------------------------------------------------------------------------
# Transmission Done Indicator -> LED LD0
set_property PACKAGE_PIN T22 [get_ports tx_done]
set_property IOSTANDARD LVCMOS33 [get_ports tx_done]

# Baseband Valid Flag Indicator -> LED LD1
set_property PACKAGE_PIN T21 [get_ports tx_valid]
set_property IOSTANDARD LVCMOS33 [get_ports tx_valid]

# Controller FIFO Overflow Alarm -> LED LD7
set_property PACKAGE_PIN U14 [get_ports fifo_overflow]
set_property IOSTANDARD LVCMOS33 [get_ports fifo_overflow]

# ------------------------------------------------------------------------------
# 5. Baseband I/Q Output Signals (Mapped to PMOD Headers JA & JB)
# Bank 13 (3.3V Voltage Domain)
# ------------------------------------------------------------------------------
# Real Baseband Component: tx_real[5:0] -> PMOD JA Pins (1, 2, 3, 4, 7, 8)
set_property PACKAGE_PIN Y11  [get_ports {tx_real[0]}] ;# JA1
set_property PACKAGE_PIN AA11 [get_ports {tx_real[1]}] ;# JA2
set_property PACKAGE_PIN Y10  [get_ports {tx_real[2]}] ;# JA3
set_property PACKAGE_PIN AA9  [get_ports {tx_real[3]}] ;# JA4
set_property PACKAGE_PIN AB11 [get_ports {tx_real[4]}] ;# JA7
set_property PACKAGE_PIN AB10 [get_ports {tx_real[5]}] ;# JA8
set_property IOSTANDARD LVCMOS33 [get_ports {tx_real[*]}]

# Imaginary Baseband Component: tx_imag[5:0] -> PMOD JB Pins (1, 2, 3, 4, 7, 8)
set_property PACKAGE_PIN W12 [get_ports {tx_imag[0]}] ;# JB1
set_property PACKAGE_PIN W11 [get_ports {tx_imag[1]}] ;# JB2
set_property PACKAGE_PIN V10 [get_ports {tx_imag[2]}] ;# JB3
set_property PACKAGE_PIN W8  [get_ports {tx_imag[3]}] ;# JB4
set_property PACKAGE_PIN V12 [get_ports {tx_imag[4]}] ;# JB7
set_property PACKAGE_PIN W10 [get_ports {tx_imag[5]}] ;# JB8
set_property IOSTANDARD LVCMOS33 [get_ports {tx_imag[*]}]

# ------------------------------------------------------------------------------
# 6. Timing Exceptions & Delay Constraints
# ------------------------------------------------------------------------------
# # Treat manual, non-clocked switch and push-button inputs as asynchronous
# set_false_path -from [get_ports reset]
# set_false_path -from [get_ports start_tx]
# set_false_path -from [get_ports {chirp_index[*]}]
# set_false_path -from [get_ports {payload_length[*]}]

set_false_path -from u_tx_datapath/u_css_symbol_generator/u_complex_multiplier/tx_imag_reg[*]/C -to  tx_imag[*]
set_false_path -from u_tx_datapath/u_css_symbol_generator/u_complex_multiplier/tx_real_reg[3]/C -to  tx_real[*]
set_false_path -from u_tx_datapath/u_css_symbol_generator/u_csk_generator/done_reg/C -to  tx_done
set_false_path -from u_tx_datapath/u_css_symbol_generator/u_complex_multiplier/valid_out_reg/C -to  tx_valid
set_false_path -from u_controller/fifo_overflow_reg/C -to fifo_overflow
set_false_path -from u_tx_datapath/u_css_symbol_generator/u_complex_multiplier/tx_real_reg[*]/C -to tx_real



# set_input_delay -from u_tx_datapath/u_css_symbol_generator/u_complex_multiplier/tx_imag_reg[0]/C -to  tx_imag[0]
# set_input_delay -from u_tx_datapath/u_css_symbol_generator/u_complex_multiplier/tx_imag_reg[1]/C -to  tx_imag[1]


# # Relax timing paths for status LED display pins
# set_false_path -to [get_ports tx_done]
# set_false_path -to [get_ports fifo_overflow]

# Set Input/Output Delay Budget for High-Speed Bus Verification (PMODs)

set_input_delay -max 0.35 -clock [get_clocks sys_clk] [get_ports reset]
set_input_delay -min 0.35 -clock [get_clocks sys_clk] [get_ports reset]
# set_input_delay -max 0.5 -clock [get_clocks clk] [get_ports payload_we]
# set_input_delay -min 0.5 -clock [get_clocks clk] [get_ports payload_we]
# set_input_delay -max 0.5 -clock [get_clocks clk] [get_ports payload_waddr]
# set_input_delay -min 0.5 -clock [get_clocks clk] [get_ports payload_waddr]
# set_input_delay -max 0.5 -clock [get_clocks clk] [get_ports payload_wdata]
# set_input_delay -min 0.5 -clock [get_clocks clk] [get_ports payload_wdata]
set_input_delay -max 0.3 -clock [get_clocks sys_clk] [get_ports payload_length]
set_input_delay -min 0.3 -clock [get_clocks sys_clk] [get_ports payload_length]
set_input_delay -max 0.3 -clock [get_clocks sys_clk] [get_ports chirp_index]
set_input_delay -min 0.3 -clock [get_clocks sys_clk] [get_ports chirp_index]
set_input_delay -max 0.3 -clock [get_clocks sys_clk] [get_ports start_tx]
set_input_delay -min 0.3 -clock [get_clocks sys_clk] [get_ports start_tx]


set_output_delay -max 0.5 -clock [get_clocks sys_clk] [get_ports tx_done]
set_output_delay -min 0.5 -clock [get_clocks sys_clk] [get_ports tx_done]
# set_output_delay -max 0.5 -clock [get_clocks clk] [get_ports tx_real]
# set_output_delay -min 0.5 -clock [get_clocks clk] [get_ports tx_real]
# set_output_delay -max 0.5 -clock [get_clocks clk] [get_ports tx_imag]
# set_output_delay -min 0.5 -clock [get_clocks clk] [get_ports tx_imag]
# set_output_delay -max 0.5 -clock [get_clocks clk] [get_ports tx_valid]
# set_output_delay -min 0.5 -clock [get_clocks clk] [get_ports tx_valid]
set_output_delay -max 0.5 -clock [get_clocks sys_clk] [get_ports fifo_overflow]
set_output_delay -min 0.5 -clock [get_clocks sys_clk] [get_ports fifo_overflow]

set_input_delay  -clock [get_clocks sys_clk] -max 0.5 [get_ports {payload_wdata[*] payload_waddr[*] payload_we}]
set_input_delay  -clock [get_clocks sys_clk] -min 0.500 [get_ports {payload_wdata[*] payload_waddr[*] payload_we}]

set_output_delay -clock [get_clocks sys_clk] -max 0.5 [get_ports {tx_real[*] tx_imag[*] tx_valid}]
set_output_delay -clock [get_clocks sys_clk] -min 0.500 [get_ports {tx_real[*] tx_imag[*] tx_valid}]

# ------------------------------------------------------------------------------
# 7. Device Configuration Settings
# ------------------------------------------------------------------------------
#set_property BITSTREAM.CONFIG.SPI_BUSWIDTH 4 [current_design]


# Un-comment one or more of the following IOSTANDARD constraints according to
# the bank pin assignments that are required within a design.
# ---------------------------------------------------------------------------- 

# Note that the bank voltage for IO Bank 33 is fixed to 3.3V on ZedBoard. 
##set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 33]];

# Set the bank voltage for IO Bank 34 to 1.8V by default.
# set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 34]];
# set_property IOSTANDARD LVCMOS25 [get_ports -of_objects [get_iobanks 34]];
##set_property IOSTANDARD LVCMOS18 [get_ports -of_objects [get_iobanks 34]];

# Set the bank voltage for IO Bank 35 to 1.8V by default.
# set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 35]];
# set_property IOSTANDARD LVCMOS25 [get_ports -of_objects [get_iobanks 35]];
##set_property IOSTANDARD LVCMOS18 [get_ports -of_objects [get_iobanks 35]];

# Note that the bank voltage for IO Bank 13 is fixed to 3.3V on ZedBoard. 
##set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 13]];
